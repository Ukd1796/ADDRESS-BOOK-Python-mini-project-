# -*- coding: utf-8 -*-
"""
Created on Thu Apr 29 14:23:10 2021

@author: Sahil
"""

class Vehicle:
    def __init__(self, name, mileage, capacity):
        self.name = name
        self.mileage = mileage
        self.capacity = capacity

    def fare(self):
        return self.capacity * 100

class Train(Vehicle):
    pass

Public_train = Train("Express", 12, 150)
print("Total fare is:", Public_train.fare())